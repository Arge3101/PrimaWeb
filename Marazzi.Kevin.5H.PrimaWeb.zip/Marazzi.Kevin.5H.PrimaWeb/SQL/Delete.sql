DELETE
FROM Prenotazioni
WHERE Nome="Pino";

SELECT *
FROM Prenotazioni;