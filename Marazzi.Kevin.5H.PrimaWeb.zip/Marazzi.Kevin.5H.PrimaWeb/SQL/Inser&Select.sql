-- SQLite
INSERT INTO Prenotazioni ( Nome, Email)
VALUES ("Pino","Pino@gmail.com");

SELECT PrenotazioneId, Nome, Email
FROM Prenotazioni;
